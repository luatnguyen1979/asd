package asd.booking.dao;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.util.List;

import asd.framework.booking.domain.Report;

public class ReportDAOTest extends TestCase {

    public void testGetList() throws Exception {
        //IReportProxy reportProxy = new ReportDaoProxy("");
        /*ReportDAO reportDAO = new ReportDAO();
        List<Report> reportList = reportDAO.getList("2017-01-01", "2018-12-31");
        Assert.assertNotNull(reportList);
        System.out.println(reportList.size());*/
    }
}