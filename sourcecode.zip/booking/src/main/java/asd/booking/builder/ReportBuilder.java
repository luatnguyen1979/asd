package asd.booking.builder;

public interface ReportBuilder<T> {

    public void build();
}
