/**
 * 
 */
package asd.booking.utils;

/**
 * @author luatnguyen
 *
 */
public enum CardType {
	VISA, DISCOVERY, MASTERCARD, AMERICANEXPRESS, JCB
}
