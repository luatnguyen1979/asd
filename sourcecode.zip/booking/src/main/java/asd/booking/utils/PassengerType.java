/**
 * 
 */
package asd.booking.utils;

/**
 * @author luatnguyen
 *
 */
public class PassengerType {
	public static final String SENIOR = "Senior";
	public static final String ADULT = "Adult";
	public static final String CHILD = "Child";
	public static final String INFANT = "Infant";
	public static final String MILITARY = "Military";
}
