/**
 * 
 */
package asd.framework.booking.logger;

/**
 * @author luatnguyen
 *
 */
public final class LogLevel {
	   public static int INFO = 1;
	   public static int DEBUG = 2;
	   public static int ERROR = 3;
}
