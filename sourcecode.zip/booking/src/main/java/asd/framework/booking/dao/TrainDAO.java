/**
 * created Jan/30/2018
 */
package asd.framework.booking.dao;

import asd.framework.booking.domain.Train;

public interface TrainDAO {
   

    public Train get(int id);
}
