package asd.framework.booking.iteration;

public interface Aggregate {

    public Iterator getIterator();
}
